module.exports = {
   SEW_QUEEN_OWNER: '94785435462,94785457519', // Ravindu Manoj - Sew Queen Owner
   SEW_QUEEN_TEAM: '94714366177,94766911891,94711031915,94757222271,94713179802', // Team - SEW QUEEN TEAM 
   QUEEN_AMDI_OWNER: '94757405652' // Black Amda - Queen Amdi Owner --> For The Friendship 
    } 
